package Telephony;

public interface Callble {
    void call();
}
