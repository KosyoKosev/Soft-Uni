package cresla.models.modules;

public class HeatProcessor extends AbstractAbsorberModule {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
