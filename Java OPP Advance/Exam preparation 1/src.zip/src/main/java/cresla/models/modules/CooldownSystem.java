package cresla.models.modules;

public class CooldownSystem extends AbstractAbsorberModule {

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
