package cresla.interfaces;

public interface InputReader {
    String readLine();
}
