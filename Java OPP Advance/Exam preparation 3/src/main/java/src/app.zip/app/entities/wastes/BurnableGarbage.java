package src.app.entities.wastes;

public class BurnableGarbage extends AbstractWaste {

    public BurnableGarbage(String name, double volumePerKg, double weight) {
        super(name, volumePerKg, weight);
    }
}
