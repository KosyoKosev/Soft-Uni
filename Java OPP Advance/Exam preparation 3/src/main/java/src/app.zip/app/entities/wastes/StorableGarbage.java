package src.app.entities.wastes;

public class StorableGarbage extends AbstractWaste {

    public StorableGarbage(String name, double volumePerKg, double weight) {
        super(name, volumePerKg, weight);
    }
}
