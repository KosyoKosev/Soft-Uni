package Playlist.Exception;

/**
 * Created by Viktoria on 21.7.2017 г..
 */
public class InvalidArtistNameException extends InvalidSongException{
    public InvalidArtistNameException(String message) {
        super(message);
    }
}
