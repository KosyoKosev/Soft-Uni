package Ferrari;

public interface Car {
    void brakes();
    void pushTheGasPedal();
}
