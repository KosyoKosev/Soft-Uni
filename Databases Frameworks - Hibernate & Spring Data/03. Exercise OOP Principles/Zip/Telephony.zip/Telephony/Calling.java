package Telephony;

public interface Calling {
    void calling(String phoneNumber);
}
