package Telephony;

public interface Browsing {
    void browsing(String urlAddress);
}
