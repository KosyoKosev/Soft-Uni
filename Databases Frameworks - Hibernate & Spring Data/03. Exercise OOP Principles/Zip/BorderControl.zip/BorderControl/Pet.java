package BorderControl;

public interface Pet extends Birthable{
    String getName();
}
