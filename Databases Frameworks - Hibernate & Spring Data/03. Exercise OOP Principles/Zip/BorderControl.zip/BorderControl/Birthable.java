package BorderControl;

public interface Birthable {
    String getBirthday();
}
