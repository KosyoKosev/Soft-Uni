package BorderControl;

public interface Citizen extends Identifible, Birthable{
    String getName();
    int getAge();
}
