package BorderControl;

public interface Identifible {
    String getId();
}
