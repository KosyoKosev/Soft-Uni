package BorderControl;

public interface Robot extends Identifible {
    String getName();
}
