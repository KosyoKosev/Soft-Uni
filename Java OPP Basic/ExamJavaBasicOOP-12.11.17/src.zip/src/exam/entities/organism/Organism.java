package exam.entities.organism;

import exam.entities.cluster.Cluster;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Organism {

    private String name;
    private Set<Cluster> clusters;

    public Organism(String name) {
        this.name = name;
        this.clusters = new LinkedHashSet<>();
    }

    public String getName() {
        return name;
    }

    public Set<Cluster> getClusters() {
        return clusters;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
            sb
                    .append(String.format("Organism - %s", this.name))
                    .append(System.lineSeparator())
                    .append(String.format("--Clusters: %d", this.clusters.size()))
                    .append(System.lineSeparator());
        return sb.toString();
    }
}
