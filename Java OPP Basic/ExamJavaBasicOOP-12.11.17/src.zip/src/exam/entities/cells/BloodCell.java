package exam.entities.cells;

public abstract class BloodCell extends Cell {

    BloodCell(String id, int health, int positionRow, int positionCol) {
        super(id, health, positionRow, positionCol);
    }
}
